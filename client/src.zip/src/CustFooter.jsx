import React from "react";
import './Content.css';
function CustFooter()
{
    return(
    
      <footer>@2023-All Copyright Reserved-MSU</footer>
      
    );
}

export default CustFooter;