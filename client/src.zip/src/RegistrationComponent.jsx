import React, { Component, useState } from "react";
// import "./loginform.css"
import Navbar from "./dashboard/Navbar";
import Sidebar from "./dashboard/Sidebar";
import back from "./bg.jpg"
class registrationform extends Component{

    constructor(props){
        super(props)
        this.state={
            Name: "",
            Branch:"",
            emailId:"",
            phoneNo:"",
            Address:"",
            Percantage_in_10th:"",
            Percantage_in_12thORDiploma:"",
            BE_Percantage:""

        }

        this.ChangeNameHandler=this.ChangeNameHandler.bind(this);
        this.ChangeBranchHandler=this.ChangeBranchHandler.bind(this);
        this.ChangeEmailHandler=this.ChangeEmailHandler.bind(this);
        this.ChangePhoneHandler=this.ChangePhoneHandler.bind(this);
        this.ChangeAddressHandler=this.ChangeAddressHandler.bind(this);
        this.ChangePercantage_10Handler=this.ChangePercantage_10Handler.bind(this);
        this.ChangePercantage_12Handler=this.ChangePercantage_12Handler.bind(this);
        this.ChangeBEPercantageHandler=this.ChangeBEPercantageHandler.bind(this);
        this.saveStudent=this.saveStudent.bind(this);
    }

    ChangeNameHandler=(event)=>{
        this.setState({Name:event.target.value});
    }
    ChangeBranchHandler=(event)=>{
        this.setState({Branch:event.target.value});
    }
    ChangeEmailHandler=(event)=>{
        this.setState({emailId:event.target.value});
    }
    ChangePhoneHandler=(event)=>{
        this.setState({phoneNo:event.target.value});
    }
    ChangeAddressHandler=(event)=>{
        this.setState({Address:event.target.value});
    }
    ChangePercantage_10Handler=(event)=>{
        this.setState({Percantage_in_10th:event.target.value});
    }
    ChangePercantage_12Handler=(event)=>{
        this.setState({Percantage_in_12thORDiploma:event.target.value});
    }
    ChangeBEPercantageHandler=(event)=>{
        this.setState({BE_Percantage:event.target.value});
    }
    saveStudent=(e)=>{
        e.preventDefault();
        let student={Name:this.state.Name,Branch:this.state.Branch,emailId:this.state.emailId,Phone:this.state.phoneNo,Address:this.state.Address,Percantage_10:this.state.Percantage_in_10th,Percantage_11:this.state.Percantage_in_12thORDiploma,BE_Percantage:this.state.BE_Percantage};
        console.log('student=>'+JSON.stringify(student));
    }
    cancel=(e)=>{
        this.props.history.push();
    }

    render(){
        return (
            <div>
              <Navbar></Navbar>
              <div class="container-fluid" id="main">
                 <div class="row row-offcanvas row-offcanvas-left">
                   <Sidebar/>
                  
               <div className="container col main pt-5 mt-5" style={{backgroundImage:"url("+back+")"}}>
                   <div className="row">
                    <br></br>
                    <h1 className="col-12 text-center" style={{color:"#6f42c1"}}> Student Registration For TNP</h1>
                    <br></br>

                      <div className="card col-md-6 offset-md-3 offset-md-3">
                         <div className="card-body">
                            <form>
                                <div className="form-group">
                                <label>Name:</label>
                                <input placeholder="Name" name="name" className="form-control" value={this.state.Name} onChange={this.ChangeNameHandler}/>
                                </div>

                                <div className="form-group">
                                <label>Branch:</label>
                                <input placeholder="Branch" name="barnch" className="form-control" value={this.state.Branch} onChange={this.ChangeBranchHandler}/>
                                </div>

                                <div className="form-group">
                                <label>Email Id:</label>
                                <input placeholder="email" name="email" className="form-control" value={this.state.emailId} onChange={this.ChangeEmailHandler}/>
                                </div>

                                <div className="form-group">
                                <label>Phone No:</label>
                                <input placeholder="PhoneNo" name="PhoneNO" className="form-control" value={this.state.phoneNo} onChange={this.ChangePhoneHandler}/>
                                </div>

                                <div className="form-group">
                                <label>Address:</label>
                                <input placeholder="Address" name="Adrress" className="form-control" value={this.state.Address} onChange={this.ChangeAddressHandler}/>
                                </div>

                                <div className="form-group">
                                <label>10th Percantage:</label>
                                <input placeholder="percantage" name="percantage" className="form-control" value={this.state.Percantage_in_10th} onChange={this.ChangePercantage_10Handler}/>
                                </div>

                                <div className="form-group">
                                <label>12th/Diploma Percantage:</label>
                                <input placeholder="percantage" name="percantage" className="form-control" value={this.state.Percantage_in_12thORDiploma} onChange={this.ChangePercantage_12Handler}/>
                                </div>

                                <div className="form-group">
                                <label>BE Percantage:</label>
                                <input placeholder="percantage" name="percantage" className="form-control" value={this.state.BE_Percantage} onChange={this.ChangeBEPercantageHandler}/>
                                </div>
                                <br></br>
                                <br></br>
                                <button className="btn btn-success" onClick={this.saveStudent}>Submit</button>
                                <button className="btn btn-danger" onClick={this.cancel.bind} style={{marginLeft:"10px"}}>cancel</button>

                            </form>
                         </div>

                      </div>
                   </div>
               </div>

            </div>
            </div>
            </div>
        )
    }
}

export default registrationform