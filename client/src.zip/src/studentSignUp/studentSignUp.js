import React from "react";
import Loginform from "./loginform";
function studentSignUp()
{
     return(
         <Loginform></Loginform>
        );
}

export default studentSignUp;